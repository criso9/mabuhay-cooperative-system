
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admins` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from` datetime NOT NULL,
  `to` datetime NOT NULL,
  `added_by` bigint(20) unsigned NOT NULL,
  `removed_by` bigint(20) unsigned NOT NULL,
  `remarks` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES (1,1,'active','2014-05-21 17:23:17','2018-04-21 17:23:17',1,0,NULL,'2018-04-21 09:23:17','2018-04-21 09:23:17'),(2,2,'active','2014-05-21 17:23:33','2018-04-21 17:23:33',1,0,NULL,'2018-04-21 09:23:33','2018-04-21 09:23:33'),(3,5,'active','2018-06-01 12:09:56','2018-06-01 12:09:56',1,0,NULL,'2018-06-01 04:09:56','2018-06-01 04:09:56'),(4,8,'active','2018-06-01 12:10:38','2018-06-01 12:10:38',1,0,NULL,'2018-06-01 04:10:38','2018-06-01 04:10:38');
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announcements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `event_date` datetime NOT NULL,
  `details` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` bigint(20) unsigned NOT NULL,
  `updated_by` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
INSERT INTO `announcements` VALUES (1,'2018-07-22 00:00:00','Good day! \r\nMeeting @ Lor\'s House , 10 AM. \r\nPlease come for an important announcement. Thank you!',8,8,'2018-05-31 18:11:04','2018-05-31 18:53:51');
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `business_incomes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `business_incomes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` bigint(20) unsigned NOT NULL,
  `amount` double(8,2) NOT NULL,
  `profit` double(8,2) NOT NULL DEFAULT '0.00',
  `date_paid` datetime NOT NULL,
  `updated_by` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `business_incomes` WRITE;
/*!40000 ALTER TABLE `business_incomes` DISABLE KEYS */;
INSERT INTO `business_incomes` VALUES (1,1,30000.00,0.00,'2018-06-01 00:00:00','5','2018-06-01 04:40:27','2018-06-01 04:40:27'),(2,1,70000.00,0.00,'2018-05-28 00:00:00','5','2018-06-01 04:40:55','2018-06-01 04:40:55'),(3,1,500.00,500.00,'2018-06-01 00:00:00','5','2018-06-01 04:41:26','2018-06-01 04:41:26'),(4,1,300.00,300.00,'2018-05-30 00:00:00','5','2018-06-01 04:52:50','2018-06-01 04:52:50');
/*!40000 ALTER TABLE `business_incomes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `businesses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `businesses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `capital` double(8,2) NOT NULL,
  `income` double(8,2) DEFAULT NULL,
  `profit` double(8,2) DEFAULT NULL,
  `date_started` date NOT NULL,
  `added_by` bigint(20) unsigned NOT NULL,
  `date_ended` date DEFAULT NULL,
  `removed_by` bigint(20) unsigned DEFAULT NULL,
  `remarks` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `businesses` WRITE;
/*!40000 ALTER TABLE `businesses` DISABLE KEYS */;
INSERT INTO `businesses` VALUES (1,'Computer Shop','Target to open this year.','Active',100000.00,100800.00,800.00,'2018-05-31',2,NULL,NULL,NULL,'2018-05-31 17:54:31','2018-06-01 04:52:50');
/*!40000 ALTER TABLE `businesses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `contributions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contributions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `payment_id` bigint(20) unsigned NOT NULL,
  `date` datetime NOT NULL,
  `amount` double(8,2) NOT NULL,
  `payment_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receipt_no` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_paid` datetime NOT NULL,
  `updated_by` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `contributions` WRITE;
/*!40000 ALTER TABLE `contributions` DISABLE KEYS */;
INSERT INTO `contributions` VALUES (1,3,2,'2018-05-31 18:17:55',300.00,'Cash','05312018-18171952','2018-05-31 18:17:00','8','2018-05-31 18:17:55','2018-05-31 18:17:55'),(2,16,1,'2018-05-31 18:21:16',300.00,'Cash','05312018-18210789','2018-05-31 18:21:00','8','2018-05-31 18:21:16','2018-05-31 18:21:16'),(3,15,1,'2018-05-31 18:21:30',600.00,'Cash','05312018-18211869','2018-05-31 18:21:00','8','2018-05-31 18:21:30','2018-05-31 18:21:30'),(4,10,3,'2018-05-31 19:21:00',100.00,'Cash','05312018-18215657','2018-05-31 19:21:00','8','2018-05-31 18:22:07','2018-05-31 18:22:07'),(5,16,1,'2018-07-01 18:22:33',300.00,'Bank','2343545','2018-05-30 18:22:00','8','2018-05-31 18:22:33','2018-05-31 18:22:33'),(7,16,1,'2018-08-31 18:23:54',300.00,'Cash','05312018-18234312','2018-05-31 18:23:00','8','2018-05-31 18:23:54','2018-05-31 18:23:54'),(10,15,1,'2018-07-01 18:30:23',100.00,'Cash','05312018-18301173','2018-05-31 18:30:00','8','2018-05-31 18:30:23','2018-05-31 18:30:23'),(11,16,1,'2018-10-01 18:30:46',300.00,'Cash','05312018-18302773','2018-05-30 18:30:00','8','2018-05-31 18:30:46','2018-05-31 18:30:46'),(12,16,1,'2018-12-01 18:31:03',300.00,'Cash','05312018-18305144','2018-05-31 18:31:00','8','2018-05-31 18:31:03','2018-05-31 18:31:03'),(14,3,1,'2018-05-31 18:44:51',300.00,'Cash','05312018-18443854','2018-05-31 18:44:00','8','2018-05-31 18:44:51','2018-05-31 18:44:51'),(16,3,1,'2018-07-31 18:45:29',600.00,'Cash','05312018-18451276','2018-05-31 18:45:00','8','2018-05-31 18:45:29','2018-05-31 18:45:29'),(18,3,1,'2018-08-31 18:46:10',100.00,'Cash','05312018-18455980','2018-05-31 18:46:00','8','2018-05-31 18:46:10','2018-05-31 18:46:10'),(20,3,1,'2018-10-31 18:46:53',300.00,'Bank','5346546','2018-05-28 18:46:00','8','2018-05-31 18:46:53','2018-05-31 18:46:53'),(21,3,1,'2018-12-01 18:47:31',600.00,'Palawan Express','64765778766','2018-05-31 18:47:00','8','2018-05-31 18:47:31','2018-05-31 18:47:31'),(22,3,1,'2018-06-01 08:53:22',300.00,'Cash','06012018-08525552','2018-06-01 08:53:00','2','2018-06-01 08:53:22','2018-06-01 08:53:22'),(24,3,1,'2018-09-01 08:56:01',300.00,'Palawan Express','5642342','2018-06-01 08:55:00','2','2018-06-01 08:56:01','2018-06-01 08:56:01'),(26,3,3,'2018-06-01 10:17:00',200.00,'Palawan Express','12345678','2018-06-01 10:17:00','2','2018-06-01 09:17:55','2018-06-01 09:17:55'),(29,10,1,'2018-11-01 09:41:57',200.00,'Cash','06012018-09413940','2018-06-01 09:41:00','2','2018-06-01 09:41:57','2018-06-01 09:41:57'),(30,11,1,'2018-11-01 09:45:55',200.00,'Cash','06012018-09453365','2018-06-01 09:45:00','2','2018-06-01 09:45:55','2018-06-01 09:45:55'),(31,3,1,'2018-11-01 09:48:23',100.00,'Cash','06012018-09481278','2018-06-01 09:48:00','2','2018-06-01 09:48:23','2018-06-01 09:48:23'),(32,4,1,'2018-06-01 09:56:06',300.00,'Cash','06012018-09555635','2018-06-01 09:56:00','2','2018-06-01 09:56:06','2018-06-01 09:56:06'),(33,4,1,'2018-07-01 09:56:44',600.00,'Bank','6575','2018-06-01 09:56:00','2','2018-06-01 09:56:44','2018-06-01 09:56:44'),(34,4,3,'2018-06-01 10:01:25',180.00,'Cash','06012018-10062525','2018-06-01 10:01:25','2','2018-06-01 10:01:25','2018-06-01 10:01:25'),(35,3,3,'2018-06-01 12:26:27',90.00,'Cash','06012018-12062727','2018-06-01 12:26:27','5','2018-06-01 04:26:27','2018-06-01 04:26:27'),(36,3,3,'2018-06-01 12:51:00',30.00,'Cash','06012018-12505843','2018-06-01 12:51:00','5','2018-06-01 04:51:06','2018-06-01 04:51:06');
/*!40000 ALTER TABLE `contributions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cooperatives`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cooperatives` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `coop_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mission` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vision` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_founded` date NOT NULL,
  `mem_int` decimal(5,2) NOT NULL,
  `nonmem_int` decimal(5,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cooperatives` WRITE;
/*!40000 ALTER TABLE `cooperatives` DISABLE KEYS */;
INSERT INTO `cooperatives` VALUES (1,'Mabuhay BNHS Cooperative','logo/logo-20180421-171645.png','icon/icon-20180414-231128.ico','Test','tEST','2014-05-05',0.02,0.10,NULL,'2018-05-31 18:07:44');
/*!40000 ALTER TABLE `cooperatives` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `files_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `files_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `files_type` WRITE;
/*!40000 ALTER TABLE `files_type` DISABLE KEYS */;
INSERT INTO `files_type` VALUES (1,'policies',NULL,NULL),(2,'minutes',NULL,NULL),(3,'attendance',NULL,NULL),(4,'others',NULL,NULL);
/*!40000 ALTER TABLE `files_type` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `files_uploaded`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `files_uploaded` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_id` bigint(20) unsigned NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `orig_file_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `added_by` bigint(20) unsigned NOT NULL,
  `added_at` datetime NOT NULL,
  `removed_by` bigint(20) unsigned DEFAULT NULL,
  `removed_at` datetime DEFAULT NULL,
  `remarks` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `files_uploaded` WRITE;
/*!40000 ALTER TABLE `files_uploaded` DISABLE KEYS */;
INSERT INTO `files_uploaded` VALUES (2,3,'active','COP.docx','3-20180415-181915-COP.docx','uploads/documents/3-20180415-181915-COP.docx',1,'2018-04-15 18:19:15',NULL,NULL,NULL,'2018-04-15 10:19:15','2018-04-15 10:19:15'),(5,1,'active','PrefixAlgorithm.doc','1-20180504-225859-PrefixAlgorithm.doc','uploads/documents/1-20180504-225859-PrefixAlgorithm.doc',1,'2018-05-04 22:58:59',NULL,NULL,NULL,'2018-05-04 14:58:59','2018-05-04 14:58:59');
/*!40000 ALTER TABLE `files_uploaded` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `images_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `images_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `images_type` WRITE;
/*!40000 ALTER TABLE `images_type` DISABLE KEYS */;
INSERT INTO `images_type` VALUES (1,'carousel',NULL,NULL),(2,'about_us',NULL,NULL),(3,'services',NULL,NULL);
/*!40000 ALTER TABLE `images_type` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `images_uploaded`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `images_uploaded` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_id` bigint(20) unsigned NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `added_by` bigint(20) unsigned NOT NULL,
  `added_at` datetime NOT NULL,
  `removed_by` bigint(20) unsigned DEFAULT NULL,
  `removed_at` datetime DEFAULT NULL,
  `remarks` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `images_uploaded` WRITE;
/*!40000 ALTER TABLE `images_uploaded` DISABLE KEYS */;
INSERT INTO `images_uploaded` VALUES (17,1,'inactive','uploads/carousel/carousel-20180415-151201-MBNHS.jpg','/test',1,'2018-04-15 15:12:01',1,'2018-04-15 16:13:34','hgfh','2018-04-15 07:12:01','2018-04-15 08:13:34'),(18,1,'inactive','uploads/carousel/carousel-20180415-151256-MBNHS2.jpg','/register',1,'2018-04-15 15:12:56',1,'2018-04-15 16:14:01','rtret','2018-04-15 07:12:56','2018-04-15 08:14:01'),(19,1,'inactive','uploads/carousel/carousel-20180415-151256-na.png','/register',1,'2018-04-15 15:12:56',1,'2018-04-15 15:13:13','fdgdzf','2018-04-15 07:12:56','2018-04-15 07:13:13'),(20,1,'inactive','uploads/carousel/carousel-20180415-161648-bmember2.jpg','/about',1,'2018-04-15 16:16:49',1,'2018-04-17 01:05:32','ggdf','2018-04-15 08:16:49','2018-04-16 17:05:32'),(21,1,'inactive','uploads/carousel/carousel-20180415-161712-cashcash.png','/services',1,'2018-04-15 16:17:12',1,'2018-04-17 01:05:37','fgfd','2018-04-15 08:17:12','2018-04-16 17:05:37'),(22,1,'inactive','uploads/carousel/carousel-20180415-161712-motmot.png','/services',1,'2018-04-15 16:17:12',1,'2018-04-17 01:05:47','fdgfdg','2018-04-15 08:17:12','2018-04-16 17:05:47'),(23,1,'inactive','uploads/carousel/carousel-20180416-235815-MBNHS.jpg','/login',4,'2018-04-16 23:58:15',1,'2018-04-17 01:05:42','fgfdg','2018-04-16 15:58:15','2018-04-16 17:05:42'),(24,1,'active','uploads/carousel/carousel-20180417-010834-MBNHS (1).JPG','/register',1,'2018-04-17 01:08:34',NULL,NULL,NULL,'2018-04-16 17:08:34','2018-04-16 17:08:34'),(25,1,'active','uploads/carousel/carousel-20180417-010903-cascash.JPG','/services',1,'2018-04-17 01:09:03',NULL,NULL,NULL,'2018-04-16 17:09:03','2018-04-16 17:09:03'),(26,1,'active','uploads/carousel/carousel-20180417-010903-motmot2.JPG','/services',1,'2018-04-17 01:09:03',NULL,NULL,NULL,'2018-04-16 17:09:03','2018-04-16 17:09:03'),(27,1,'inactive','uploads/carousel/carousel-20180531-180507-missionvision.JPG','MisionVision',2,'2018-05-31 18:05:07',2,'2018-06-01 08:48:36','removed','2018-05-31 18:05:07','2018-06-01 08:48:36'),(28,1,'active','uploads/carousel/carousel-20180601-084925-MV.JPG','/missionvision',2,'2018-06-01 08:49:25',NULL,NULL,NULL,'2018-06-01 08:49:25','2018-06-01 08:49:25');
/*!40000 ALTER TABLE `images_uploaded` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `interest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `interest` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rate` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `actual_value` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `interest` WRITE;
/*!40000 ALTER TABLE `interest` DISABLE KEYS */;
INSERT INTO `interest` VALUES (1,'Member','2','0.02',NULL,NULL),(2,'Non-member','10','',NULL,NULL),(3,'Share Capital','3','0.03',NULL,NULL);
/*!40000 ALTER TABLE `interest` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `loan_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loan_payments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double(8,2) NOT NULL,
  `interest_amount` double(8,2) DEFAULT NULL,
  `sharecap_amount` double(8,2) DEFAULT NULL,
  `date_paid` datetime NOT NULL,
  `payment_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receipt_no` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_by` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `loan_payments` WRITE;
/*!40000 ALTER TABLE `loan_payments` DISABLE KEYS */;
INSERT INTO `loan_payments` VALUES (1,'20180106-09583808-4',116.67,NULL,NULL,'2018-06-01 10:05:00','Cash','06012018-10050118','2','2018-06-01 10:05:56','2018-06-01 10:05:56'),(2,'20180106-09583808-4',47.22,NULL,NULL,'2018-06-01 10:08:00','Cash','06012018-10081463','2','2018-06-01 10:08:28','2018-06-01 10:08:28'),(3,'20180106-09583808-4',39.35,NULL,NULL,'2018-06-01 10:11:00','Cash','06012018-10090566','2','2018-06-01 10:11:33','2018-06-01 10:11:33'),(4,'20180106-12253894-3',70.00,NULL,NULL,'2018-06-01 12:43:00','Cash','06012018-12432795','1','2018-06-01 04:43:42','2018-06-01 04:43:42'),(5,'20180106-12183278-3',166.67,20.00,30.00,'2018-06-01 12:51:00','Cash','06012018-12505843','5','2018-06-01 04:51:06','2018-06-01 04:51:06'),(6,'20180106-09583808-4',39.35,NULL,NULL,'2018-06-01 13:32:00','Cash','06012018-13323239','1','2018-06-01 05:32:56','2018-06-01 05:32:56');
/*!40000 ALTER TABLE `loan_payments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `loans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loans` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `transaction_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_applied` datetime NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loan_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount_loan` double(8,2) NOT NULL,
  `amount_repayable` double(8,2) NOT NULL DEFAULT '0.00',
  `amount_paid` double(8,2) NOT NULL DEFAULT '0.00',
  `interest_amount` double(8,2) NOT NULL DEFAULT '0.00',
  `interest_amount_paid` double(8,2) NOT NULL DEFAULT '0.00',
  `scapital_amount` double(8,2) NOT NULL DEFAULT '0.00',
  `scapital_amount_paid` double(8,2) NOT NULL DEFAULT '0.00',
  `remaining_balance` double(8,2) NOT NULL DEFAULT '0.00',
  `due_date` datetime DEFAULT NULL,
  `reviewed_by` bigint(20) unsigned DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `remarks` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `loans_transaction_no_unique` (`transaction_no`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `loans` WRITE;
/*!40000 ALTER TABLE `loans` DISABLE KEYS */;
INSERT INTO `loans` VALUES (1,3,'20183105-17322862-3','Rejected','2018-05-31 17:34:46','','Motor',50000.00,86000.00,0.00,36000.00,0.00,0.00,0.00,86000.00,NULL,5,'2018-06-01 12:23:52','cannot loan','2018-05-31 17:34:46','2018-06-01 04:23:52'),(2,4,'20180106-09583808-4','Active','2018-06-01 09:59:09','d','Cash',1000.00,700.00,242.59,120.00,120.00,180.00,180.00,157.41,'2018-12-01 10:01:25',2,'2018-06-01 10:01:25',NULL,'2018-06-01 09:59:09','2018-06-01 05:32:56'),(3,4,'20180106-09593236-4','Pending','2018-06-01 10:00:19','','Motor',100000.00,172000.00,0.00,72000.00,0.00,0.00,0.00,172000.00,NULL,NULL,NULL,NULL,'2018-06-01 10:00:19','2018-06-01 10:00:19'),(4,3,'20180106-12183278-3','Active','2018-06-01 12:22:01','a','Cash',1000.00,1300.00,166.67,120.00,20.00,180.00,30.00,1083.33,'2018-12-01 12:45:54',1,'2018-06-01 12:45:54',NULL,'2018-06-01 04:22:01','2018-06-01 04:51:07'),(5,3,'20180106-12253894-3','Active','2018-06-01 12:25:51','d','Cash',500.00,350.00,70.00,60.00,60.00,90.00,90.00,130.00,'2018-12-01 12:26:27',5,'2018-06-01 12:26:27',NULL,'2018-06-01 04:25:51','2018-06-01 04:43:42'),(6,3,'20180106-13190978-3','Pending','2018-06-01 13:20:12','','Motor',104550.00,179826.00,0.00,75276.00,0.00,0.00,0.00,179826.00,NULL,NULL,NULL,NULL,'2018-06-01 05:20:12','2018-06-01 05:20:12');
/*!40000 ALTER TABLE `loans` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2018_01_24_141914_create_roles_table',1),(4,'2018_01_24_141915_create_roles_table',2),(5,'2018_27_01_000002_create_users_table',3),(10,'2018_02_04_061801_create_cooperatives_table',4),(18,'2018_27_01_000003_create_users_table',5),(19,'2018_02_19_162253_create_monthly_contribution_table',6),(20,'2018_02_19_061801_create_cooperatives_table',7),(21,'2018_02_26_162253_create_monthly_contribution_table',8),(22,'2018_02_26_162255_create_monthly_contribution_table',9),(23,'2018_02_26_162255_create_contributions_table',10),(24,'2018_03_05_225737_create_payments_table',10),(25,'2018_03_09_132841_create_interest_table',11),(26,'2018_02_26_162250_create_contributions_table',12),(27,'2018_03_10_173557_create_positions_table',13),(28,'2018_03_10_174938_create_officers_table',14),(29,'2018_27_01_000004_create_users_table',15),(30,'2018_03_10_174939_create_officers_table',16),(31,'2018_03_10_174940_create_officers_table',17),(32,'2018_03_10_174941_create_officers_table',18),(33,'2018_03_10_174942_create_officers_table',19),(34,'2018_03_10_173558_create_positions_table',20),(35,'2018_03_10_174943_create_officers_table',21),(36,'2018_03_10_174944_create_officers_table',22),(37,'2018_27_01_000005_create_users_table',23),(38,'2018_27_01_000006_create_users_table',24),(39,'2018_27_01_000007_create_users_table',25),(40,'2018_02_19_061802_create_cooperatives_table',26),(41,'2018_03_18_150659_create_users_table',27),(42,'2018_03_20_211356_create_admins_table',28),(43,'2018_03_18_150601_create_users_table',29),(44,'2018_03_28_220617_create_loans_table',30),(47,'2018_03_28_220618_create_loans_table',31),(48,'2018_04_09_182838_create_business_table',32),(49,'2018_04_11_220846_create_carousels_table',33),(50,'2018_02_19_061803_create_cooperatives_table',34),(51,'2018_04_11_220846_create_images_uploaded_table',35),(52,'2018_04_14_232824_create_images_type_table',36),(53,'2018_04_11_220847_create_images_uploaded_table',37),(54,'2018_04_11_220848_create_images_uploaded_table',38),(55,'2018_04_15_162249_create_files_uploaded_table',39),(56,'2018_04_15_162432_create_files_type_table',39),(57,'2018_04_15_162250_create_files_uploaded_table',40),(58,'2018_04_15_162251_create_files_uploaded_table',41),(59,'2018_03_28_220619_create_loans_table',42),(60,'2018_04_16_181212_create_loans_payment_table',43),(61,'2018_03_28_220620_create_loans_table',44),(62,'2018_04_16_181213_create_loans_payment_table',44),(63,'2018_05_10_203555_create_business_income_table',45),(64,'2018_04_09_182839_create_business_table',46),(65,'2017_01_23_115718_create_polls_table',47),(66,'2017_01_23_124357_create_options_table',47),(67,'2017_01_25_111721_create_votes_table',47),(68,'2018_05_25_225647_create_announcements_table',48),(69,'2018_05_25_225648_create_announcements_table',49),(70,'2018_05_25_225649_create_announcements_table',50),(71,'2018_03_28_220621_create_loans_table',51),(72,'2018_03_28_220622_create_loans_table',52),(73,'2018_03_28_220623_create_loans_table',53),(74,'2018_03_28_220624_create_loans_table',54),(75,'2018_03_28_220625_create_loans_table',55),(76,'2018_04_16_181214_create_loans_payment_table',56),(77,'2018_03_28_220626_create_loans_table',57),(78,'2018_05_10_203556_create_business_income_table',58);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `monthly_contribution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `monthly_contribution` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `date` datetime NOT NULL,
  `amount` double(8,2) NOT NULL,
  `payment` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receipt_no` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_by` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `monthly_contribution` WRITE;
/*!40000 ALTER TABLE `monthly_contribution` DISABLE KEYS */;
/*!40000 ALTER TABLE `monthly_contribution` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `officers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `officers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `position_id` bigint(20) unsigned NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from` datetime NOT NULL,
  `to` datetime NOT NULL,
  `added_by` bigint(20) unsigned NOT NULL,
  `removed_by` bigint(20) unsigned NOT NULL,
  `remarks` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `officers` WRITE;
/*!40000 ALTER TABLE `officers` DISABLE KEYS */;
INSERT INTO `officers` VALUES (1,8,4,'active','2018-05-31 17:14:12','2018-05-31 17:14:12',1,0,NULL,'2018-05-31 17:14:12','2018-05-31 17:14:12'),(2,1,5,'inactive','2018-05-31 17:48:32','2018-05-31 17:49:21',2,2,'Removed','2018-05-31 17:48:32','2018-05-31 17:49:21'),(3,11,7,'active','2018-05-31 17:55:15','2018-05-31 17:55:15',1,0,NULL,'2018-05-31 17:55:15','2018-05-31 17:55:15'),(4,5,1,'active','2018-06-01 12:10:14','2018-06-01 12:10:14',1,0,NULL,'2018-06-01 04:10:14','2018-06-01 04:10:14');
/*!40000 ALTER TABLE `officers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `options` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `poll_id` int(10) unsigned NOT NULL,
  `votes` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `options_poll_id_foreign` (`poll_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `options` WRITE;
/*!40000 ALTER TABLE `options` DISABLE KEYS */;
INSERT INTO `options` VALUES (1,'yes',1,0,'2018-06-01 04:35:36','2018-06-01 04:35:36'),(2,'no',1,0,'2018-06-01 04:35:36','2018-06-01 04:35:36'),(3,'yes',2,0,'2018-06-01 04:35:56','2018-06-01 04:35:56'),(4,'no',2,0,'2018-06-01 04:35:56','2018-06-01 04:35:56'),(5,'yes',3,0,'2018-06-01 05:03:38','2018-06-01 05:03:38'),(6,'no',3,0,'2018-06-01 05:03:38','2018-06-01 05:03:38');
/*!40000 ALTER TABLE `options` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `payment` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES (1,'Monthly Contribution','2018-03-04 16:00:00','2018-03-04 16:00:00'),(2,'Damayan','2018-03-04 16:00:00','2018-03-04 16:00:00'),(3,'Share Capital','2018-03-04 16:00:00','2018-03-04 16:00:00');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `polls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `polls` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `question` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `maxCheck` int(11) NOT NULL DEFAULT '1',
  `isClosed` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `polls` WRITE;
/*!40000 ALTER TABLE `polls` DISABLE KEYS */;
INSERT INTO `polls` VALUES (1,'are you going to the next meeting on July 22, 2018?',1,0,'2018-06-01 04:35:36','2018-06-01 04:35:36'),(2,'how are you?',1,1,'2018-06-01 04:35:56','2018-06-01 05:03:23'),(3,'are you okay?',1,0,'2018-06-01 05:03:38','2018-06-01 05:03:38');
/*!40000 ALTER TABLE `polls` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `positions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `positions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `position` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `positions` WRITE;
/*!40000 ALTER TABLE `positions` DISABLE KEYS */;
INSERT INTO `positions` VALUES (1,'President','individual',NULL,NULL),(2,'Vice President','individual',NULL,NULL),(3,'Secretary','individual',NULL,NULL),(4,'Treasurer','individual',NULL,NULL),(5,'Asst. Treasurer','individual',NULL,NULL),(6,'Auditor','individual',NULL,NULL),(7,'PIO','individual',NULL,NULL),(8,'Sgt./Arms','individual',NULL,NULL),(9,'Chairman of the Board','individual',NULL,NULL),(10,'Board Members','group',NULL,NULL);
/*!40000 ALTER TABLE `positions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_role_name_unique` (`role_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'admin',NULL,NULL),(2,'officer',NULL,NULL),(3,'member',NULL,NULL),(4,'root',NULL,NULL);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `f_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `l_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `m_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `b_date` date NOT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `civil_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `referral` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_relation` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reviewed_by` bigint(20) unsigned DEFAULT NULL,
  `remarks_reviewed` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `activated_at` datetime DEFAULT NULL,
  `changestat_by` bigint(20) unsigned DEFAULT NULL,
  `remarks_changestat` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `changestat_at` datetime DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Carissa','Navarroza',NULL,'09151178289','taguig city','1995-11-15','Female','Single','crisnavz.cn@gmail.com','$2y$10$S9B1ZahoAc1AL8Z.kFq48e9ViSpC3rPuf7qrfg9NsFutyH19OWIwa','marites','mother','pic-20180601-121212-20170321_065457.jpg','active','4',NULL,NULL,NULL,'2018-03-24 01:34:36',NULL,NULL,NULL,'buv1JtTAwmB9moHxy0rpbMNjrBUvAIexUfi9EOd9c84TEWcSGsob538T7szJ',NULL,'2018-06-01 04:50:24'),(2,'CG','Marfil','Punzalan','09209472852','Taguig City','1996-04-13','Female','Single','claudinegailmarfil.pointman@gmail.com','$2y$10$HuZk.L99Kilpm62MtAENvOIHAzClRDRJz33ILPl53s/FnwSWNUfHy',NULL,NULL,'pic-20180601-084723-IMG_20180407_155109.jpg','active','4',NULL,NULL,NULL,'2018-03-24 01:34:36',NULL,NULL,NULL,'xvxiwUidme0JgSh7mbUBHr041KNyWDWJsZ4hYHO7leZab0Dj1JrTcZrGArRn',NULL,'2018-06-01 09:36:40'),(3,'Donna','Vinculado',NULL,'09087246793','Taguig City','1990-05-15','Female','Single','donnavinc0@gmail.com','$2y$10$E3nYBtYwLKMieeobZG8sQee1LWfFdkWYLSbPQTmSei.0sQyVnp/T2','marites','relative','pic-20180601-121235-3ae70bb248901a89587739992e4559d8-carpa-koi-icon-by-vexels.png','active','3',1,NULL,'2018-03-24 01:34:36','2018-03-24 01:34:36',NULL,NULL,NULL,'f4fiyxjNKubq4ywqd5glf98ahNUfRVujRGD4YjLWgcYrU6FmIsa3ckUAjH7q',NULL,'2018-06-01 04:12:35'),(4,'Mikko','Piccio',NULL,'12345','taguig city','1990-05-15','male','single','mikopiccio@gmail.com','$2y$10$LN6h3UiFswhtov55TDF0xuQEpsyHm81zP2oxFFgvu3luEjWYDoJxi',NULL,NULL,'user-male.png','active','3',1,NULL,'2018-03-24 01:34:36','2018-03-24 01:34:36',NULL,NULL,NULL,'KxpKPKJcUZ0JvsfWQ9m1VdVrbW96FmKbBk0blBIRPlvHJB2kmYvetojIOOFb',NULL,NULL),(5,'Reynaldo','Ranuco Sr.',NULL,'09951916225','caloocan','1990-05-15','Male','Single','reyranucs@gmail.com','$2y$10$NBF5gsl9LxoHWZ7fvxjmzeq587mPM86uJaz0oskQWwLSxiUEbgkni',NULL,NULL,'pic-20180601-133515-13M253245a1Z-FA44.jpg','active','1',1,NULL,'2018-03-24 01:34:36','2018-03-24 01:34:36',NULL,NULL,NULL,'yy6bZMGYpG9xsRKYizI3DjCv7PLIwsV9lQsyc5q1L458F0YY1Msuxrb7P4X0',NULL,'2018-06-01 05:35:15'),(6,'Lucena','Piccio',NULL,'12345','taguig city','1990-05-15','female','single','lucena@gmail.com','$2y$10$3s1URjiwTv0z93G1vz9dgeIdoJ84BFcU.FI30oF55KyEEJxJdOYte',NULL,NULL,'user-female.png','active','3',1,NULL,'2018-03-24 01:34:36','2018-03-24 01:34:36',NULL,NULL,NULL,NULL,NULL,NULL),(7,'Maria Teresa','Navarroza',NULL,'12345','taguig city','1990-05-15','female','single','marites@gmail.com','$2y$10$QtTgG8GiXwhwS1RcCUZ.1uBX2KAPZYh8X19CycFDpyVE7pj27uAPS',NULL,NULL,'user-female.png','active','3',1,NULL,'2018-03-24 01:34:36','2018-03-24 01:34:36',NULL,NULL,NULL,'SouL2DZTjX4J7k1QC3Bfp3p0nNAOgbnCgE0ztepZUnjPjmGFH1Gt36jzCQeM',NULL,'2018-05-04 13:46:23'),(8,'Melodina','Vales',NULL,'12345','taguig city','1990-05-15','Female','Married','meloselav@gmail.com','$2y$10$0QLmWf7HDZi7oD1ratpm1.WlKSMVpBk6YjPmsD/FMEDmtx8.18bRW',NULL,NULL,'pic-20180531-110154-3ae70bb248901a89587739992e4559d8-carpa-koi-icon-by-vexels.png','active','1',1,NULL,'2018-03-24 01:34:36','2018-03-24 01:34:36',NULL,NULL,NULL,'aOVvWgMljv8Wgx7gMN3ay7R5nVKKzew3YBf3O2PVghtqv0XHSlFkxKr5TTbc',NULL,'2018-06-01 04:10:38'),(9,'Roserea','Vales',NULL,'12345','taguig city','1990-05-15','female','single','roserea@gmail.com','$2y$10$nLYIBchf9wXAtwCt7YvSyuXxH0lDr5oKNYgjct28jmCWxWQdZwF3K',NULL,NULL,'user-female.png','active','3',1,NULL,'2018-03-24 01:34:36','2018-03-24 01:34:36',NULL,NULL,NULL,'a9PIJfpyiwokuqDnM71vGtdcmnKS6QPwTVS6OcxwNEsDcvQKVyAluwNMcgcq',NULL,NULL),(10,'Virgenia','Lor',NULL,'12345','taguig city','1990-05-15','female','single','virgenia@gmail.com','$2y$10$pNsh9EoW7ms5fnJfvpKzcuJJ9e.PLGATmw7AwYiiEwWvQ43cMkppC',NULL,NULL,'user-female.png','active','3',1,NULL,'2018-03-24 01:34:36','2018-03-24 01:34:36',5,'test','2018-05-31 12:22:04',NULL,NULL,'2018-05-31 04:22:04'),(11,'Cindy','Navarroza','Maga','12345','Taguig City','2000-02-28','Female','Single','cindynav88@gmail.com','$2y$10$aUwZO.VJuWfHSaQTYRCz6uVnAfrcM9Tlw/aKjMOKamad/XYFvghXm',NULL,NULL,'user-female.png','active','2',1,NULL,'2018-03-24 01:34:36','2018-03-24 01:34:36',NULL,NULL,NULL,'dUGE1Qs4UENZSNav17yxgMJbD5knUyECCKwuwabujbQjWU75ybMbtZ3ZPtAN',NULL,'2018-05-31 18:49:10'),(12,'Nilo','Vales',NULL,'12345','taguig city','1990-05-15','male','single','nilo@gmail.com','$2y$10$xrceAefF6HohWzrlxE8M0.ES7OiE4p7Q2mfAR/XCdIqS.A0xKrhCq',NULL,NULL,'user-male.png','active','3',1,NULL,'2018-03-24 01:34:36','2018-03-24 01:34:36',NULL,NULL,NULL,'JBYlqVemuUetmLbF1woZGMCWXYi0TQ442KMeKVMQQGp1F2j0J0iOEeDDQmLD',NULL,NULL),(13,'Demetria','Ziganay',NULL,'12345','taguig city','1990-05-15','female','single','demetria@gmail.com','$2y$10$RO61A0VXehIyZDdV8w4D.OUgT2AorTeq.WXa3dfK8qAl./jJSJWtu',NULL,NULL,'user-female.png','active','3',1,NULL,'2018-03-24 01:34:36','2018-03-24 01:34:36',NULL,NULL,NULL,NULL,NULL,NULL),(14,'Florenciano','Zarco',NULL,'12345','taguig city','1990-05-15','male','single','florenciano@gmail.com','$2y$10$UJXAroWd9ZH6xV60SGmfkeBnEIUXI60j5DmMcCq/iEV381sh3S8o6',NULL,NULL,'user-male.png','active','3',1,NULL,'2018-03-24 01:34:36','2018-03-24 01:34:36',NULL,NULL,NULL,'1G7HvTodLIIXVLKvnlOWKmlN5owaVmFQTslDoptf1hRYN6fa8csC4vUaw00C',NULL,NULL),(15,'Rodolfo','Lamadora',NULL,'12345','taguig city','1990-05-15','male','single','rodolfo@gmail.com','$2y$10$n3Ekz.vlzuduGBRIWAuVIOinaprCP5GJK.M4D0c7SiKXY/0e4R0Ka',NULL,NULL,'user-male.png','active','3',1,NULL,'2018-03-24 01:34:36','2018-03-24 01:34:36',NULL,NULL,NULL,'w2kYdujBJVvPLhBXnXB049Tjl26dikAhTOdnjSAhYEDh5cYApEpi9br6qw6q',NULL,NULL),(16,'Miraflor','Balderama',NULL,'12345','taguig city','1990-05-15','female','single','miraflor@gmail.com','$2y$10$ee3SGoJDdelZVYzVAxm4VeL3a/Aw1DFlxMGAabzKO21XDp27CKLEi',NULL,NULL,'user-female.png','active','3',1,NULL,'2018-03-24 01:34:36','2018-03-24 01:34:36',1,'Test','2018-05-31 17:04:23','t6CccBGw8OIRl14g8lL7aS48sB2OIMnFsqyxEmsO7WVqdbPU8bPRrrb3d26S',NULL,'2018-05-31 17:04:23'),(22,'Claud','Marfil','ew','12345','ewrw','1999-04-30','Male','Single','heypigy@gmail.com','$2y$10$PdJM4AmNWXQov26R0XjXXOdJIEJ1NpemIxXYaoHJ3og0/YJyY/PAK','carissa','Friends of Friends','user-male.png','rejected','3',2,'already have an account','2018-05-31 17:51:16',NULL,NULL,NULL,NULL,NULL,'2018-05-31 17:22:43','2018-05-31 17:51:16'),(23,'Angelika Dinah','Ranuco','Tamondez','09262925503','#30 Sapphire St. Payatas Area B, Quezon City','2000-03-03','Female','Single','ranucoangelika03@gmail.com','$2y$10$Ds5DL4Ar8JW/ZjfilT/5IulesInRzcanpk/Mba/V1SsWfk3ZBm9TW',NULL,NULL,'user-female.png','active','3',1,NULL,'2018-06-01 10:04:43','2018-06-01 10:04:57',NULL,NULL,NULL,NULL,'2018-06-01 10:01:58','2018-06-01 10:04:57');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users_02012018`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_02012018` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users_02012018` WRITE;
/*!40000 ALTER TABLE `users_02012018` DISABLE KEYS */;
INSERT INTO `users_02012018` VALUES (1,'carissa','car@email.com','$2y$10$h9Qc9ALANJwoP8LfpAKIRePvCJlzShvB8JzsnS/3bN1O0V3EGjq4i','user-female.png','1',NULL,NULL,NULL),(2,'miko piccio','mpiccio@email.com','123','user-male.png','3',NULL,NULL,NULL),(3,'donna vinculado','dvinculado@email.com','123','user-female.png','3',NULL,NULL,NULL);
/*!40000 ALTER TABLE `users_02012018` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `votes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `votes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `option_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `votes_option_id_foreign` (`option_id`),
  KEY `votes_user_id_foreign` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `votes` WRITE;
/*!40000 ALTER TABLE `votes` DISABLE KEYS */;
INSERT INTO `votes` VALUES (1,3,5,'2018-06-01 05:03:56','2018-06-01 05:03:56'),(2,5,1,'2018-06-01 05:34:37','2018-06-01 05:34:37');
/*!40000 ALTER TABLE `votes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

