$(document).ready(function () {
  $(window).load(function(){
    $('.preloader').delay(800).fadeOut(500);
  })

})