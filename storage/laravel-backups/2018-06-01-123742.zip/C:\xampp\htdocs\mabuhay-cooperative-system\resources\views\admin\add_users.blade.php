@extends('layout.panel')

@section('title')
Admin - Add Users
@stop

@section('content')

<div class="flex-center position-ref full-height">
  <div class="col-md-12 col-sm-12 col-xs-12">
    <div class="x_panel">
      <div class="x_title">

        <h2>Add Members <small></small></h2>
        <div class="clearfix"></div>
      </div>
      <div class="x_content">
      	<br/>
  	  </div>

	</div>
  </div>
</div>

@stop