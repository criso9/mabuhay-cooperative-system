
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admins` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from` datetime NOT NULL,
  `to` datetime NOT NULL,
  `added_by` bigint(20) unsigned NOT NULL,
  `removed_by` bigint(20) unsigned NOT NULL,
  `remarks` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES (1,8,'active','2014-05-21 17:23:17','2018-04-21 17:23:17',1,0,NULL,'2018-04-21 09:23:17','2018-04-21 09:23:17'),(2,5,'active','2014-05-21 17:23:33','2018-04-21 17:23:33',1,0,NULL,'2018-04-21 09:23:33','2018-04-21 09:23:33');
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `businesses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `businesses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `capital` double(8,2) NOT NULL,
  `interest` double(8,2) DEFAULT NULL,
  `date_started` date NOT NULL,
  `added_by` bigint(20) unsigned NOT NULL,
  `date_ended` date DEFAULT NULL,
  `removed_by` bigint(20) unsigned DEFAULT NULL,
  `remarks` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `businesses` WRITE;
/*!40000 ALTER TABLE `businesses` DISABLE KEYS */;
INSERT INTO `businesses` VALUES (1,'test','test only','Inactive',1000.00,NULL,'2018-04-09',1,'2018-04-09',1,'yeeeaahh','2018-04-09 12:39:39','2018-04-09 13:52:51'),(2,'test2','test only','Active',2000.00,NULL,'2018-04-08',1,NULL,NULL,NULL,'2018-04-09 13:43:40','2018-04-09 13:43:40'),(3,'Computer Shop','1 PC only','Inactive',4000.00,NULL,'2018-02-06',7,'2018-04-16',7,'broken PC','2018-04-16 03:16:34','2018-04-16 03:16:52'),(4,'palayan','fertilizer','Inactive',1500.00,NULL,'2018-04-01',7,'2018-04-16',7,'yutuyt','2018-04-16 03:22:08','2018-04-16 03:24:10'),(5,'test5','sfasfsa','Active',300.00,NULL,'2018-04-01',7,NULL,NULL,NULL,'2018-04-16 03:23:10','2018-04-16 03:23:10'),(6,'test5','sfasfsa','Inactive',300.00,NULL,'2018-04-01',7,'2018-04-16',4,'iuhpoin','2018-04-16 03:23:23','2018-04-16 15:53:22'),(7,'test5','sfasfsa','Inactive',300.00,NULL,'2018-04-01',7,'2018-04-16',7,'6uytut','2018-04-16 03:23:32','2018-04-16 03:23:49');
/*!40000 ALTER TABLE `businesses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `contributions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contributions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `payment_id` bigint(20) unsigned NOT NULL,
  `date` datetime NOT NULL,
  `amount` double(8,2) NOT NULL,
  `payment_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receipt_no` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_paid` datetime NOT NULL,
  `updated_by` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `contributions` WRITE;
/*!40000 ALTER TABLE `contributions` DISABLE KEYS */;
INSERT INTO `contributions` VALUES (1,14,1,'2018-04-16 09:58:15',200.00,'Cash','04162018-09575617','2018-04-16 09:55:00','7','2018-04-16 01:58:15','2018-04-16 01:58:15'),(2,9,1,'2018-04-16 10:13:29',250.00,'Cash','04162018-10131832','2018-04-16 10:13:00','7','2018-04-16 02:13:29','2018-04-16 02:13:29'),(3,14,1,'2018-05-16 10:13:45',150.00,'Cash','04162018-10133749','2018-04-16 10:13:00','7','2018-04-16 02:13:45','2018-04-16 02:13:45'),(4,14,1,'2018-04-16 10:43:07',100.00,'Palawan Express','04162018-10430098','2018-04-16 10:42:00','7','2018-04-16 02:43:07','2018-04-16 02:43:07'),(5,6,1,'2018-04-16 14:54:34',100.00,'Cash','04162018-14541625','2018-04-16 14:54:00','7','2018-04-16 06:54:34','2018-04-16 06:54:34'),(6,13,1,'2018-04-16 15:06:07',300.00,'Cash','04162018-15055257','2018-04-16 15:06:00','7','2018-04-16 07:06:07','2018-04-16 07:06:07'),(7,13,1,'2018-05-16 15:06:23',250.00,'Cash','04162018-15062068','2018-04-16 15:06:00','7','2018-04-16 07:06:23','2018-04-16 07:06:23'),(8,4,1,'2018-04-16 17:05:04',300.00,'Cash','04162018-17045699','2018-04-16 17:05:00','7','2018-04-16 09:05:04','2018-04-16 09:05:04'),(9,7,1,'2018-04-16 21:28:02',200.00,'Cash','04162018-21275257','2018-04-16 21:28:00','4','2018-04-16 13:28:02','2018-04-16 13:28:02'),(10,6,1,'2018-04-16 23:27:09',300.00,'Cash','04162018-23265090','2018-04-10 23:27:00','4','2018-04-16 15:27:09','2018-04-16 15:27:09');
/*!40000 ALTER TABLE `contributions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cooperatives`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cooperatives` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `coop_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mission` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vision` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_founded` date NOT NULL,
  `mem_int` decimal(5,2) NOT NULL,
  `nonmem_int` decimal(5,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cooperatives` WRITE;
/*!40000 ALTER TABLE `cooperatives` DISABLE KEYS */;
INSERT INTO `cooperatives` VALUES (1,'Mabuhay BNHS','logo/logo-20180421-171645.png','icon/icon-20180414-231128.ico','Test','tEST','2014-05-05',0.02,0.10,NULL,'2018-04-21 09:16:45');
/*!40000 ALTER TABLE `cooperatives` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `files_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `files_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `files_type` WRITE;
/*!40000 ALTER TABLE `files_type` DISABLE KEYS */;
INSERT INTO `files_type` VALUES (1,'policies',NULL,NULL),(2,'minutes',NULL,NULL),(3,'others',NULL,NULL);
/*!40000 ALTER TABLE `files_type` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `files_uploaded`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `files_uploaded` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_id` bigint(20) unsigned NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `orig_file_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `added_by` bigint(20) unsigned NOT NULL,
  `added_at` datetime NOT NULL,
  `removed_by` bigint(20) unsigned DEFAULT NULL,
  `removed_at` datetime DEFAULT NULL,
  `remarks` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `files_uploaded` WRITE;
/*!40000 ALTER TABLE `files_uploaded` DISABLE KEYS */;
INSERT INTO `files_uploaded` VALUES (1,3,'active','COP-BTIT.docx','3-20180415-181630-COP-BTIT.docx','uploads/documents/3-20180415-181630-COP-BTIT.docx',1,'2018-04-15 18:16:30',NULL,NULL,NULL,'2018-04-15 10:16:30','2018-04-15 10:16:30'),(2,3,'active','COP.docx','3-20180415-181915-COP.docx','uploads/documents/3-20180415-181915-COP.docx',1,'2018-04-15 18:19:15',NULL,NULL,NULL,'2018-04-15 10:19:15','2018-04-15 10:19:15');
/*!40000 ALTER TABLE `files_uploaded` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `images_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `images_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `images_type` WRITE;
/*!40000 ALTER TABLE `images_type` DISABLE KEYS */;
INSERT INTO `images_type` VALUES (1,'carousel',NULL,NULL),(2,'about_us',NULL,NULL),(3,'services',NULL,NULL);
/*!40000 ALTER TABLE `images_type` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `images_uploaded`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `images_uploaded` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_id` bigint(20) unsigned NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `added_by` bigint(20) unsigned NOT NULL,
  `added_at` datetime NOT NULL,
  `removed_by` bigint(20) unsigned DEFAULT NULL,
  `removed_at` datetime DEFAULT NULL,
  `remarks` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `images_uploaded` WRITE;
/*!40000 ALTER TABLE `images_uploaded` DISABLE KEYS */;
INSERT INTO `images_uploaded` VALUES (17,1,'inactive','uploads/carousel/carousel-20180415-151201-MBNHS.jpg','/test',1,'2018-04-15 15:12:01',1,'2018-04-15 16:13:34','hgfh','2018-04-15 07:12:01','2018-04-15 08:13:34'),(18,1,'inactive','uploads/carousel/carousel-20180415-151256-MBNHS2.jpg','/register',1,'2018-04-15 15:12:56',1,'2018-04-15 16:14:01','rtret','2018-04-15 07:12:56','2018-04-15 08:14:01'),(19,1,'inactive','uploads/carousel/carousel-20180415-151256-na.png','/register',1,'2018-04-15 15:12:56',1,'2018-04-15 15:13:13','fdgdzf','2018-04-15 07:12:56','2018-04-15 07:13:13'),(20,1,'inactive','uploads/carousel/carousel-20180415-161648-bmember2.jpg','/about',1,'2018-04-15 16:16:49',1,'2018-04-17 01:05:32','ggdf','2018-04-15 08:16:49','2018-04-16 17:05:32'),(21,1,'inactive','uploads/carousel/carousel-20180415-161712-cashcash.png','/services',1,'2018-04-15 16:17:12',1,'2018-04-17 01:05:37','fgfd','2018-04-15 08:17:12','2018-04-16 17:05:37'),(22,1,'inactive','uploads/carousel/carousel-20180415-161712-motmot.png','/services',1,'2018-04-15 16:17:12',1,'2018-04-17 01:05:47','fdgfdg','2018-04-15 08:17:12','2018-04-16 17:05:47'),(23,1,'inactive','uploads/carousel/carousel-20180416-235815-MBNHS.jpg','/login',4,'2018-04-16 23:58:15',1,'2018-04-17 01:05:42','fgfdg','2018-04-16 15:58:15','2018-04-16 17:05:42'),(24,1,'active','uploads/carousel/carousel-20180417-010834-MBNHS (1).JPG','/register',1,'2018-04-17 01:08:34',NULL,NULL,NULL,'2018-04-16 17:08:34','2018-04-16 17:08:34'),(25,1,'active','uploads/carousel/carousel-20180417-010903-cascash.JPG','/services',1,'2018-04-17 01:09:03',NULL,NULL,NULL,'2018-04-16 17:09:03','2018-04-16 17:09:03'),(26,1,'active','uploads/carousel/carousel-20180417-010903-motmot2.JPG','/services',1,'2018-04-17 01:09:03',NULL,NULL,NULL,'2018-04-16 17:09:03','2018-04-16 17:09:03');
/*!40000 ALTER TABLE `images_uploaded` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `interest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `interest` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rate` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `interest` WRITE;
/*!40000 ALTER TABLE `interest` DISABLE KEYS */;
INSERT INTO `interest` VALUES (1,'Member','2',NULL,NULL),(2,'Non-member','10',NULL,NULL);
/*!40000 ALTER TABLE `interest` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `loan_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loan_payments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double(8,2) NOT NULL,
  `interest_amount` double(8,2) NOT NULL,
  `date_paid` datetime NOT NULL,
  `payment_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receipt_no` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_by` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `loan_payments` WRITE;
/*!40000 ALTER TABLE `loan_payments` DISABLE KEYS */;
INSERT INTO `loan_payments` VALUES (1,'20181604-19255976-13',100.00,6.00,'2018-04-16 19:34:00','Cash','04162018-19340218','7','2018-04-16 11:34:14','2018-04-16 11:34:14'),(2,'20181604-19255976-13',50.00,6.00,'2018-04-16 19:38:00','Cash','04162018-19383271','7','2018-04-16 11:38:39','2018-04-16 11:38:39'),(3,'20181604-22471473-4',200.00,6.00,'2018-04-17 00:03:00','Cash','04172018-00032482','7','2018-04-16 16:03:53','2018-04-16 16:03:53'),(4,'20181604-22471473-4',100.00,5.00,'2018-04-17 00:04:00','Cash','04172018-00042489','7','2018-04-16 16:04:36','2018-04-16 16:04:36'),(5,'20181604-23553414-4',50.00,0.00,'2018-04-21 22:19:00','Cash','04212018-22185937','8','2018-04-21 14:19:15','2018-04-21 14:19:15'),(6,'20181604-23553414-4',50.00,0.00,'2018-04-21 22:19:00','Cash','04212018-22185937','8','2018-04-21 14:19:56','2018-04-21 14:19:56');
/*!40000 ALTER TABLE `loan_payments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `loans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loans` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `transaction_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_applied` datetime NOT NULL,
  `amount_loan` double(8,2) NOT NULL,
  `amount_paid` double(8,2) DEFAULT NULL,
  `interest_amount` double(8,2) DEFAULT NULL,
  `remaining_balance` double(8,2) DEFAULT NULL,
  `due_date` datetime DEFAULT NULL,
  `reviewed_by` bigint(20) unsigned DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `remarks` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `loans_transaction_no_unique` (`transaction_no`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `loans` WRITE;
/*!40000 ALTER TABLE `loans` DISABLE KEYS */;
INSERT INTO `loans` VALUES (1,13,'20181604-19255976-13','Active','2018-04-16 19:26:07',300.00,150.00,12.00,300.00,'2018-10-16 19:26:31',7,'2018-04-16 19:26:31',NULL,'2018-04-16 11:26:07','2018-04-16 11:38:39'),(2,13,'20181604-19264048-13','Rejected','2018-04-16 19:26:44',100.00,NULL,NULL,NULL,NULL,7,'2018-04-16 19:27:11','test','2018-04-16 11:26:44','2018-04-16 11:27:11'),(3,13,'20181604-19325460-13','Rejected','2018-04-16 19:32:59',200.00,NULL,NULL,NULL,NULL,7,'2018-04-16 19:33:18','test','2018-04-16 11:32:59','2018-04-16 11:33:18'),(4,13,'20181604-20353239-13','Rejected','2018-04-16 20:35:37',200.00,NULL,NULL,NULL,NULL,4,'2018-04-16 21:27:36','dfsfs','2018-04-16 12:35:37','2018-04-16 13:27:36'),(5,13,'20181604-20394166-13','Rejected','2018-04-16 20:39:46',100.00,NULL,NULL,NULL,NULL,4,'2018-04-16 20:41:00','test','2018-04-16 12:39:46','2018-04-16 12:41:00'),(6,4,'20181604-21263752-4','Active','2018-04-16 21:26:42',200.00,NULL,NULL,200.00,'2018-10-16 21:48:17',7,'2018-04-16 21:48:17',NULL,'2018-04-16 13:26:42','2018-04-16 13:48:17'),(7,7,'20181604-21294959-7','Active','2018-04-16 21:29:53',100.00,NULL,NULL,100.00,'2018-10-16 22:14:58',4,'2018-04-16 22:14:58',NULL,'2018-04-16 13:29:53','2018-04-16 14:14:58'),(8,13,'20181604-22134836-13','Active','2018-04-16 22:13:53',100.00,NULL,NULL,100.00,'2018-10-16 22:48:38',4,'2018-04-16 22:48:38',NULL,'2018-04-16 14:13:53','2018-04-16 14:48:38'),(9,4,'20181604-22471473-4','Active','2018-04-16 22:47:19',100.00,300.00,11.00,100.00,'2018-10-16 22:47:39',7,'2018-04-16 22:47:39',NULL,'2018-04-16 14:47:19','2018-04-16 16:04:36'),(10,4,'20181604-23292264-4','Pending','2018-04-16 23:30:08',100.00,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-04-16 15:30:08','2018-04-16 15:30:08'),(11,4,'20181604-23553414-4','Active','2018-04-16 23:57:11',100.00,50.00,0.00,50.00,'2018-10-17 00:03:20',7,'2018-04-17 00:03:20',NULL,'2018-04-16 15:57:11','2018-04-21 14:19:57'),(12,14,'20181704-12172541-14','Pending','2018-04-17 12:17:35',300.00,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-04-17 04:17:35','2018-04-17 04:17:35');
/*!40000 ALTER TABLE `loans` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2018_01_24_141914_create_roles_table',1),(4,'2018_01_24_141915_create_roles_table',2),(5,'2018_27_01_000002_create_users_table',3),(10,'2018_02_04_061801_create_cooperatives_table',4),(18,'2018_27_01_000003_create_users_table',5),(19,'2018_02_19_162253_create_monthly_contribution_table',6),(20,'2018_02_19_061801_create_cooperatives_table',7),(21,'2018_02_26_162253_create_monthly_contribution_table',8),(22,'2018_02_26_162255_create_monthly_contribution_table',9),(23,'2018_02_26_162255_create_contributions_table',10),(24,'2018_03_05_225737_create_payments_table',10),(25,'2018_03_09_132841_create_interest_table',11),(26,'2018_02_26_162250_create_contributions_table',12),(27,'2018_03_10_173557_create_positions_table',13),(28,'2018_03_10_174938_create_officers_table',14),(29,'2018_27_01_000004_create_users_table',15),(30,'2018_03_10_174939_create_officers_table',16),(31,'2018_03_10_174940_create_officers_table',17),(32,'2018_03_10_174941_create_officers_table',18),(33,'2018_03_10_174942_create_officers_table',19),(34,'2018_03_10_173558_create_positions_table',20),(35,'2018_03_10_174943_create_officers_table',21),(36,'2018_03_10_174944_create_officers_table',22),(37,'2018_27_01_000005_create_users_table',23),(38,'2018_27_01_000006_create_users_table',24),(39,'2018_27_01_000007_create_users_table',25),(40,'2018_02_19_061802_create_cooperatives_table',26),(41,'2018_03_18_150659_create_users_table',27),(42,'2018_03_20_211356_create_admins_table',28),(43,'2018_03_18_150601_create_users_table',29),(44,'2018_03_28_220617_create_loans_table',30),(47,'2018_03_28_220618_create_loans_table',31),(48,'2018_04_09_182838_create_business_table',32),(49,'2018_04_11_220846_create_carousels_table',33),(50,'2018_02_19_061803_create_cooperatives_table',34),(51,'2018_04_11_220846_create_images_uploaded_table',35),(52,'2018_04_14_232824_create_images_type_table',36),(53,'2018_04_11_220847_create_images_uploaded_table',37),(54,'2018_04_11_220848_create_images_uploaded_table',38),(55,'2018_04_15_162249_create_files_uploaded_table',39),(56,'2018_04_15_162432_create_files_type_table',39),(57,'2018_04_15_162250_create_files_uploaded_table',40),(58,'2018_04_15_162251_create_files_uploaded_table',41),(59,'2018_03_28_220619_create_loans_table',42),(60,'2018_04_16_181212_create_loans_payment_table',43),(61,'2018_03_28_220620_create_loans_table',44),(62,'2018_04_16_181213_create_loans_payment_table',44);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `monthly_contribution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `monthly_contribution` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `date` datetime NOT NULL,
  `amount` double(8,2) NOT NULL,
  `payment` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receipt_no` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_by` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `monthly_contribution` WRITE;
/*!40000 ALTER TABLE `monthly_contribution` DISABLE KEYS */;
INSERT INTO `monthly_contribution` VALUES (1,1,'2018-01-08 14:51:00',200.00,'Bank','123456','4','2018-02-26 06:52:29','2018-02-26 06:52:29'),(2,1,'2018-02-22 14:53:00',100.00,'Palawan Express','12345','4','2018-02-26 06:54:09','2018-02-26 06:54:09'),(3,2,'2018-01-09 14:55:00',200.00,'Palawan Express','745745','4','2018-02-26 06:56:02','2018-02-26 06:56:02'),(4,2,'2018-02-08 14:56:00',300.00,'Palawan Express','678678','4','2018-02-26 06:56:14','2018-02-26 06:56:14'),(5,2,'2018-03-27 18:37:00',500.00,'Bank','12345','4','2018-03-02 09:37:54','2018-03-02 09:37:54'),(6,1,'2018-03-05 23:45:00',250.00,'Bank','123','4','2018-03-05 14:45:24','2018-03-05 14:45:24'),(7,1,'2018-03-05 23:45:00',250.00,'Bank','123','4','2018-03-05 14:45:52','2018-03-05 14:45:52'),(8,2,'2018-04-19 23:47:00',200.00,'Bank','678','4','2018-03-05 14:47:42','2018-03-05 14:47:42');
/*!40000 ALTER TABLE `monthly_contribution` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `officers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `officers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `position_id` bigint(20) unsigned NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from` datetime NOT NULL,
  `to` datetime NOT NULL,
  `added_by` bigint(20) unsigned NOT NULL,
  `removed_by` bigint(20) unsigned NOT NULL,
  `remarks` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `officers` WRITE;
/*!40000 ALTER TABLE `officers` DISABLE KEYS */;
INSERT INTO `officers` VALUES (1,8,4,'active','2014-05-21 22:02:50','2018-04-21 22:02:50',1,0,NULL,'2018-04-21 14:02:50','2018-04-21 14:02:50'),(2,5,1,'inactive','2014-05-21 22:03:53','2018-04-21 22:04:20',1,1,'test','2018-04-21 14:03:53','2018-04-21 14:04:20');
/*!40000 ALTER TABLE `officers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `payment` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES (1,'Monthly Contribution','2018-03-04 16:00:00','2018-03-04 16:00:00'),(2,'Damayan','2018-03-04 16:00:00','2018-03-04 16:00:00'),(3,'Share Capital','2018-03-04 16:00:00','2018-03-04 16:00:00');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `positions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `positions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `position` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `positions` WRITE;
/*!40000 ALTER TABLE `positions` DISABLE KEYS */;
INSERT INTO `positions` VALUES (1,'President','individual',NULL,NULL),(2,'Vice President','individual',NULL,NULL),(3,'Secretary','individual',NULL,NULL),(4,'Treasurer','individual',NULL,NULL),(5,'Asst. Treasurer','individual',NULL,NULL),(6,'Auditor','individual',NULL,NULL),(7,'PIO','individual',NULL,NULL),(8,'Sgt./Arms','individual',NULL,NULL),(9,'Chairman of the Board','individual',NULL,NULL),(10,'Board Members','group',NULL,NULL);
/*!40000 ALTER TABLE `positions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_role_name_unique` (`role_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'admin',NULL,NULL),(2,'officer',NULL,NULL),(3,'member',NULL,NULL);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `f_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `l_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `m_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `b_date` date NOT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `civil_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `referral` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_relation` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reviewed_by` bigint(20) unsigned DEFAULT NULL,
  `remarks_reviewed` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `activated_at` datetime DEFAULT NULL,
  `changestat_by` bigint(20) unsigned DEFAULT NULL,
  `remarks_changestat` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `changestat_at` datetime DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Carissa','Navarroza',NULL,'12345','taguig city','1995-11-15','female','single','admin@gmail.com','$2y$10$wFlWt..sQj8XXNBJZVMUeeRtrC4xAgPK41mmGbEXo38SB0g51CxT6','marites','mother','user-female.png','active','1',NULL,NULL,NULL,'2018-03-24 01:34:36',NULL,NULL,NULL,'FoC53NDOEYPdZfCHKKcAAcMNvuRH3T5MdumitZvt0sS71KMVIAEEEX3L6eaN',NULL,NULL),(2,'Claudine','Marfil',NULL,'12345','taguig city','1996-04-13','female','single','claud@gmail.com','$2y$10$NV6IEqxC0bNQhow5ggHYDu6zrhUKvTDhfxkokbsXXCv.JPQWTbnMi',NULL,NULL,'user-female.png','active','1',NULL,NULL,NULL,'2018-03-24 01:34:36',NULL,NULL,NULL,NULL,NULL,NULL),(3,'Donna','Vinculado',NULL,'12345','taguig city','1990-05-15','female','single','donna@gmail.com','$2y$10$E3nYBtYwLKMieeobZG8sQee1LWfFdkWYLSbPQTmSei.0sQyVnp/T2','marites','relative','user-female.png','active','3',1,NULL,'2018-03-24 01:34:36','2018-03-24 01:34:36',NULL,NULL,NULL,NULL,NULL,NULL),(4,'Mikko','Piccio',NULL,'12345','taguig city','1990-05-15','male','single','mikko@gmail.com','$2y$10$LN6h3UiFswhtov55TDF0xuQEpsyHm81zP2oxFFgvu3luEjWYDoJxi',NULL,NULL,'user-male.png','active','3',1,NULL,'2018-03-24 01:34:36','2018-03-24 01:34:36',NULL,NULL,NULL,NULL,NULL,NULL),(5,'Reynaldo','Ranuco Sr.',NULL,'12345','taguig city','1990-05-15','male','single','reynaldo@gmail.com','$2y$10$NBF5gsl9LxoHWZ7fvxjmzeq587mPM86uJaz0oskQWwLSxiUEbgkni',NULL,NULL,'user-male.png','active','1',1,NULL,'2018-03-24 01:34:36','2018-03-24 01:34:36',NULL,NULL,NULL,'7JrKNkPN2o4mXq0QWVwCwSykhFoY9MTs9Q4FuBHM8FteVRbC5f7hzvrbIr5i',NULL,'2018-04-17 04:13:54'),(6,'Lucena','Piccio',NULL,'12345','taguig city','1990-05-15','female','single','lucena@gmail.com','$2y$10$3s1URjiwTv0z93G1vz9dgeIdoJ84BFcU.FI30oF55KyEEJxJdOYte',NULL,NULL,'user-female.png','active','3',1,NULL,'2018-03-24 01:34:36','2018-03-24 01:34:36',NULL,NULL,NULL,NULL,NULL,NULL),(7,'Maria Teresa','Navarroza',NULL,'12345','taguig city','1990-05-15','female','single','marites@gmail.com','$2y$10$QtTgG8GiXwhwS1RcCUZ.1uBX2KAPZYh8X19CycFDpyVE7pj27uAPS',NULL,NULL,'user-female.png','active','3',1,NULL,'2018-03-24 01:34:36','2018-03-24 01:34:36',NULL,NULL,NULL,NULL,NULL,NULL),(8,'Melodina','Vales',NULL,'12345','taguig city','1990-05-15','female','single','melodina@gmail.com','$2y$10$0QLmWf7HDZi7oD1ratpm1.WlKSMVpBk6YjPmsD/FMEDmtx8.18bRW',NULL,NULL,'user-female.png','active','1',1,NULL,'2018-03-24 01:34:36','2018-03-24 01:34:36',NULL,NULL,NULL,'xW3zWpNv9lklm6f86LAmqyJWY3AgAsDKpk6SxthNoVlHEIOBjT5LS25uAXJx',NULL,'2018-04-21 09:23:17'),(9,'Roserea','Vales',NULL,'12345','taguig city','1990-05-15','female','single','roserea@gmail.com','$2y$10$nLYIBchf9wXAtwCt7YvSyuXxH0lDr5oKNYgjct28jmCWxWQdZwF3K',NULL,NULL,'user-female.png','active','3',1,NULL,'2018-03-24 01:34:36','2018-03-24 01:34:36',NULL,NULL,NULL,NULL,NULL,NULL),(10,'Virgenia','Lor',NULL,'12345','taguig city','1990-05-15','female','single','virgenia@gmail.com','$2y$10$pNsh9EoW7ms5fnJfvpKzcuJJ9e.PLGATmw7AwYiiEwWvQ43cMkppC',NULL,NULL,'user-female.png','active','3',1,NULL,'2018-03-24 01:34:36','2018-03-24 01:34:36',NULL,NULL,NULL,NULL,NULL,NULL),(11,'Cindy','Navarroza',NULL,'12345','taguig city','1990-05-15','female','single','cindy@gmail.com','$2y$10$aUwZO.VJuWfHSaQTYRCz6uVnAfrcM9Tlw/aKjMOKamad/XYFvghXm',NULL,NULL,'user-female.png','active','3',1,NULL,'2018-03-24 01:34:36','2018-03-24 01:34:36',NULL,NULL,NULL,NULL,NULL,NULL),(12,'Nilo','Vales',NULL,'12345','taguig city','1990-05-15','male','single','nilo@gmail.com','$2y$10$xrceAefF6HohWzrlxE8M0.ES7OiE4p7Q2mfAR/XCdIqS.A0xKrhCq',NULL,NULL,'user-male.png','active','3',1,NULL,'2018-03-24 01:34:36','2018-03-24 01:34:36',NULL,NULL,NULL,NULL,NULL,NULL),(13,'Demetria','Ziganay',NULL,'12345','taguig city','1990-05-15','female','single','demetria@gmail.com','$2y$10$RO61A0VXehIyZDdV8w4D.OUgT2AorTeq.WXa3dfK8qAl./jJSJWtu',NULL,NULL,'user-female.png','active','3',1,NULL,'2018-03-24 01:34:36','2018-03-24 01:34:36',NULL,NULL,NULL,NULL,NULL,NULL),(14,'Florenciano','Zarco',NULL,'12345','taguig city','1990-05-15','male','single','florenciano@gmail.com','$2y$10$UJXAroWd9ZH6xV60SGmfkeBnEIUXI60j5DmMcCq/iEV381sh3S8o6',NULL,NULL,'user-male.png','active','3',1,NULL,'2018-03-24 01:34:36','2018-03-24 01:34:36',NULL,NULL,NULL,'1G7HvTodLIIXVLKvnlOWKmlN5owaVmFQTslDoptf1hRYN6fa8csC4vUaw00C',NULL,NULL),(15,'Rodolfo','Lamadora',NULL,'12345','taguig city','1990-05-15','male','single','rodolfo@gmail.com','$2y$10$n3Ekz.vlzuduGBRIWAuVIOinaprCP5GJK.M4D0c7SiKXY/0e4R0Ka',NULL,NULL,'user-male.png','active','3',1,NULL,'2018-03-24 01:34:36','2018-03-24 01:34:36',NULL,NULL,NULL,NULL,NULL,NULL),(16,'Miraflor','Balderama',NULL,'12345','taguig city','1990-05-15','female','single','miraflor@gmail.com','$2y$10$ee3SGoJDdelZVYzVAxm4VeL3a/Aw1DFlxMGAabzKO21XDp27CKLEi',NULL,NULL,'user-female.png','Active','3',1,NULL,'2018-03-24 01:34:36','2018-03-24 01:34:36',NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users_02012018`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_02012018` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users_02012018` WRITE;
/*!40000 ALTER TABLE `users_02012018` DISABLE KEYS */;
INSERT INTO `users_02012018` VALUES (1,'carissa','car@email.com','$2y$10$h9Qc9ALANJwoP8LfpAKIRePvCJlzShvB8JzsnS/3bN1O0V3EGjq4i','user-female.png','1',NULL,NULL,NULL),(2,'miko piccio','mpiccio@email.com','123','user-male.png','3',NULL,NULL,NULL),(3,'donna vinculado','dvinculado@email.com','123','user-female.png','3',NULL,NULL,NULL);
/*!40000 ALTER TABLE `users_02012018` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

