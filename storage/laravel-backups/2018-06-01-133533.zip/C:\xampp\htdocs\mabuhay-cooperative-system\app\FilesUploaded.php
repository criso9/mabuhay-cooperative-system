<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FilesUploaded extends Model
{
    protected $table = 'files_uploaded';

    public static $docs_rules = [
    ];
}
