<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BusinessIncome extends Model
{
    protected $table = 'business_incomes';
}
