<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ImagesUploaded extends Model
{
    protected $table = 'images_uploaded';
}
