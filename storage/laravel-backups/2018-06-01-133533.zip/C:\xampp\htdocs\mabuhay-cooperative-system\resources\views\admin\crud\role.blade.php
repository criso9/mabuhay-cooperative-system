@extends('layout.panel')

@section('content')

<div class="flex-center position-ref full-height">
    <div>
		<p>This is for testing only</p>
    </div>
</div>

@stop